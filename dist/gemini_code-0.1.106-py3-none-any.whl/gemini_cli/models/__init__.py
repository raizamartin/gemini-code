"""
Model interfaces for different LLM providers.
"""